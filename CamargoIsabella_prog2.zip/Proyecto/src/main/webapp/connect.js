function getVetsData() {
	$.ajax({
		method: "GET",
		url: "http://localhost:8080/Vet/VerTodosLosVeterinarios",
		success: function(data) {
			for (const vet of data) {
                console.log(vet)
				$('#vetSelect').append('<option value="' + vet.document + '">' + vet.name + '</option>');
			}
		},
        error: function(xhr, status, error) {
			
			console.log("[ERROR]");
		}
	});
}

getVetsData();


function getAllAnimals() {
	$.ajax({
		method: "GET",
		url: "http://localhost:8080/Animal/TodosLosAnimales",
		success: function(data) {
			for (const animal of data) {
                console.log(animal)
				$('#animal-table').append(`
				 <tr>
                 <th>
                                            <span class="custom-checkbox">
                                                <input type="checkbox" id="checkbox1" name="options[]" value="1">
                                                <label for="checkbox1"></label>
                                            </span>
                                        </th>
				    <th>${animal.id}</th>
				    <th>${animal.species}</th>
				    <th>${animal.animalDocument}</th>
				    <th>${animal.name}</th>
				    <th>${animal.breed}</th>
				    <th>${animal.ownerDocument}</th>
                    <th>${animal.ownerName}</th>
                    <th>${animal.vetDocument}</th>
                    <td>
                                            <a href="#editEmployeeModal" class="edit" data-toggle="modal" id="edit($event)"><i
                                                    class="material-icons" data-toggle="tooltip"
                                                    title="Edit">&#xE254;</i></a>
                                            <a href="#deleteEmployeeModal" class="delete" data-toggle="modal"><i
                                                    class="material-icons" data-toggle="tooltip"
                                                    title="Delete">&#xE872;</i></a>
                                        </td>
				  </tr>
				`);
			}
		},
        error: function(xhr, status, error) {
			
			console.log("[ERROR]");
		}
	});
}

getAllAnimals()


function agregarAnimal(e) {
	e.preventDefault();
	const body = {
		'species': $('#species').val(),
		'animalDocument': $('#animalDocument').val(),
		'name': $('#name').val(),
		'breed': $('#breed').val(),
		'ownerDocument': $('#ownerDocument').val(),
        'vetDocument': $('#vetSelect').val(),
	}
	$.ajax({
		method: "POST",
		url: "http://localhost:8080/Animal/AgregarPerro",
		data: body,
		success: function(data) {
			 location.reload()
		},
		error: function(xhr, status, error) {
			console.log("[ERROR]");
			console.log(xhr);
		}
	});
}

$('#add-animal').submit(agregarAnimal);




// function eliminarVehiculo(e) {
// 	e.preventDefault();
// 	const body = {
// 		'registration': $('#eliminarMatricula').val(),
// 	}
// 	$.ajax({
// 		method: "DELETE",
// 		url: "http://localhost:8080/VehicleController/DeleteVehicle/" + $('#eliminarMatricula').val(),
// 		data: body,
// 		success: function(data) {
// 			Swal.fire({
// 				icon: 'success',
// 				title: 'Eliminado',
// 			}).then(() => location.reload());
// 		},
// 		error: function(xhr, status, error) {
// 			if (+xhr.status === 404) {
// 				Swal.fire({
// 					icon: 'warning',
// 					title: 'Warning',
// 					text: xhr.responseText,
// 				});
// 			}
// 			console.log("[ERROR]");
// 			console.log(xhr);
// 		}
// 	});
// }

// $('#delete-vehicle-form').submit(eliminarVehiculo);




// function agregarPersona(e) {
// 	e.preventDefault();
// 	const body = {
// 		'name': $('#nombre-persona').val(),
// 		'document': $('#documento-persona').val(),
// 		'age': $('#edad-persona').val(),
// 	}
// 	$.ajax({
// 		method: "POST",
// 		url: "http://localhost:8080/PersonController/AddPerson",
// 		data: body,
// 		success: function(data) {
// 			Swal.fire({
// 				icon: 'success',
// 				title: 'Agregado',
// 			}).then(() => location.reload());
// 		},
// 		error: function(xhr, status, error) {
// 			if (+xhr.status === 412) {
// 				Swal.fire({
// 					icon: 'warning',
// 					title: 'Warning',
// 					text: xhr.responseText,
// 				});
// 			}
// 			console.log("[ERROR]");
// 			console.log(xhr);
// 		}
// 	});
// }

// $('#add-person-form').submit(agregarPersona);


// function agregarInfraccion(e) {
// 	e.preventDefault();
// 	const body = {
// 		'registration': $('#matricula-penalty').val(),
// 		'infringement': $('#infringement2').val(),
// 	}
// 	$.ajax({
// 		method: "PUT",
// 		url: "http://localhost:8080/VehicleController/AddInfringement/" + $('#matricula-penalty').val(),
// 		data: body,
// 		success: function(data) {
// 			Swal.fire({
// 				icon: 'success',
// 				title: 'Agregado',
// 			}).then(() => location.reload());
// 		},
// 		error: function(xhr, status, error) {
// 			if (+xhr.status === 412) {
// 				Swal.fire({
// 					icon: 'warning',
// 					title: 'Warning',
// 					text: xhr.responseText,
// 				});
// 			}
// 			console.log("[ERROR]");
// 			console.log(xhr);
// 		}
// 	});
// }

// $('#add-penalty-form').submit(agregarInfraccion);


// function eliminarInfraccion(e) {
// 	e.preventDefault();
// 	const body = {
// 		'registration': $('#matricula-penalty-remove').val(),
// 		'infringement': $('#codigo-infraccion-remove').val(),
// 	}
// 	$.ajax({
// 		method: "PUT",
// 		url: "http://localhost:8080/VehicleController/DeleteInfringement/" + $('#matricula-penalty-remove').val(),
// 		data: body,
// 		success: function(data) {
// 			Swal.fire({
// 				icon: 'success',
// 				title: 'Eliminado',
// 			}).then(() => location.reload());
// 		},
// 		error: function(xhr, status, error) {
// 			if (+xhr.status === 412) {
// 				Swal.fire({
// 					icon: 'warning',
// 					title: 'Warning',
// 					text: xhr.responseText,
// 				});
// 			}
// 			console.log("[ERROR]");
// 			console.log(xhr);
// 		}
// 	});
// }


// $('#remove-penalty-form').submit(eliminarInfraccion);




// function eliminarPersona(e) {
// 	e.preventDefault();
// 	const body = {
// 		'document': $('#eliminarPersona').val(),
// 	}
// 	$.ajax({
// 		method: "DELETE",
// 		url: "http://localhost:8080/PersonController/DeletePerson/" + $('#eliminarPersona').val(),
// 		data: body,
// 		success: function(data) {
// 			Swal.fire({
// 				icon: 'success',
// 				title: 'Eliminado',
// 			}).then(() => location.reload());
// 		},
// 		error: function(xhr, status, error) {
// 			if (+xhr.status === 412) {
// 				Swal.fire({
// 					icon: 'warning',
// 					title: 'Warning',
// 					text: xhr.responseText,
// 				});
// 			}
// 			console.log("[ERROR]");
// 			console.log(xhr);
// 		}
// 	});
// }


// $('#delete-person-form').submit(eliminarPersona);